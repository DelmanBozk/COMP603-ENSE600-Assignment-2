/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package guishoppingprogram;

/**
 *
 * @author ivan
 */

public class SimpleTestRunner {
    public static void main(String[] args) {
        System.out.println("=== Running Basic Tests ===\n");
        
        try {
            // Test 1: Cart functionality
            System.out.println("Test 1: Cart Operations");
            Cart cart = new Cart();
            Product product = new Product(1, "Test", 10.0, "Desc");
            cart.addProduct(product, 2);
            assert cart.getItems().size() == 1 : "Cart should have 1 item";
            System.out.println("✓ Cart test passed");
            
            // Test 2: CartItem functionality  
            System.out.println("Test 2: CartItem Operations");
            CartItem item = new CartItem(product, 3);
            assert item.getTotalPrice() == 30.0 : "Total should be 30.0";
            System.out.println("✓ CartItem test passed");
            
            // Test 3: Product functionality
            System.out.println("Test 3: Product Operations");
            Product p = new Product(2, "Apple", 2.5, "Fresh");
            assert p.getName().equals("Apple") : "Name should be Apple";
            System.out.println("✓ Product test passed");
            
            // Test 4: Cart total
            System.out.println("Test 4: Cart Total");
            assert cart.getTotal() == 20.0 : "Cart total should be 20.0";
            System.out.println("✓ Cart total test passed");
            
            // Test 5: Quantity update
            System.out.println("Test 5: Quantity Update");
            item.setQuantity(5);
            assert item.getQuantity() == 5 : "Quantity should be 5";
            System.out.println("✓ Quantity test passed");
            
            System.out.println("\n✅ All 5 tests passed!");
            
        } catch (Exception e) {
            System.out.println("❌ Test failed: " + e.getMessage());
        }
    }
}