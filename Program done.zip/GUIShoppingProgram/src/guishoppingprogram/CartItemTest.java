/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package guishoppingprogram;

/**
 *
 * @author ivan
 */

public class CartItemTest {

    public void testCartItemCreation() {
        Product product = new Product(1, "Test", 10.0, "Desc");
        CartItem item = new CartItem(product, 3);
        
        assert item.getProduct().equals(product) : "Product should match";
        assert item.getQuantity() == 3 : "Quantity should be 3";
        assert item.getTotalPrice() == 30.0 : "Total price should be 30.0";
        System.out.println("testCartItemCreation: PASSED");
    }

    public void testSetQuantity() {
        Product product = new Product(1, "Test", 5.0, "Desc");
        CartItem item = new CartItem(product, 2);
        
        item.setQuantity(5);
        assert item.getQuantity() == 5 : "Quantity should be 5";
        assert item.getTotalPrice() == 25.0 : "Total price should be 25.0";
        System.out.println("testSetQuantity: PASSED");
    }

    public void testToString() {
        Product product = new Product(1, "Apple", 2.0, "Fresh");
        CartItem item = new CartItem(product, 4);
        
        String result = item.toString();
        assert result.contains("Apple") : "Should contain product name";
        assert result.contains("4") : "Should contain quantity";
        assert result.contains("8.0") : "Should contain total price";
        System.out.println("testToString: PASSED");
    }
}