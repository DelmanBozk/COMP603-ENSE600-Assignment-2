/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package guishoppingprogram;

/**
 *
 * @author ivan
 */

public class ProductDAOTest {

    public void setUp() {
        try {
            DatabaseSetup.init();
        } catch (Exception e) {
            // Table might already exist
        }
    }

    public void testGetAllProducts() {
        setUp();
        ProductDAO dao = new ProductDAO();
        var products = dao.getAllProducts();
        assert products != null : "Products list should not be null";
        System.out.println("testGetAllProducts: PASSED");
    }

    public void testGetProductByName() {
        setUp();
        ProductDAO dao = new ProductDAO();
        Product product = dao.getProductByName("Apples");
        System.out.println("testGetProductByName: PASSED");
    }
}