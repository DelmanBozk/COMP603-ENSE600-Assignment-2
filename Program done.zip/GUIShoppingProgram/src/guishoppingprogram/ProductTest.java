/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package guishoppingprogram;

/**
 *
 * @author ivan
 */

public class ProductTest {

    public void testProductCreation() {
        Product product = new Product(1, "Test", 10.0, "Description");
        assert product.getId() == 1 : "ID should be 1";
        assert product.getName().equals("Test") : "Name should be Test";
        assert product.getPrice() == 10.0 : "Price should be 10.0";
        assert product.getDescription().equals("Description") : "Description should match";
        System.out.println("testProductCreation: PASSED");
    }

    public void testProductGetters() {
        Product product = new Product(2, "Banana", 1.5, "Fresh banana");
        assert product.getId() == 2 : "ID should be 2";
        assert product.getName().equals("Banana") : "Name should be Banana";
        assert product.getPrice() == 1.5 : "Price should be 1.5";
        assert product.getDescription().equals("Fresh banana") : "Description should match";
        System.out.println("testProductGetters: PASSED");
    }
}