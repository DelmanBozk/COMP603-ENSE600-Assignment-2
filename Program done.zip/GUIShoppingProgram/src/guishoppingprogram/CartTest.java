/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package guishoppingprogram;

/**
 *
 * @author ivan
 */

public class CartTest {
    private Cart cart;
    private Product testProduct;

    public void setUp() {
        cart = new Cart();
        testProduct = new Product(1, "Test Product", 10.0, "Test Description");
    }

    public void testAddProduct() {
        setUp();
        cart.addProduct(testProduct, 2);
        assert cart.getItems().size() == 1 : "Cart should have 1 item";
        assert cart.getItems().get(0).getProduct().getName().equals("Test Product") : "Product name should match";
        System.out.println("testAddProduct: PASSED");
    }

    public void testAddDuplicateProduct() {
        setUp();
        cart.addProduct(testProduct, 2);
        cart.addProduct(testProduct, 3);
        assert cart.getItems().size() == 1 : "Cart should still have 1 item for duplicates";
        assert cart.getItems().get(0).getQuantity() == 5 : "Quantity should be 5";
        System.out.println("testAddDuplicateProduct: PASSED");
    }

    public void testRemoveProduct() {
        setUp();
        cart.addProduct(testProduct, 2);
        cart.removeProduct(testProduct);
        assert cart.isEmpty() : "Cart should be empty after removal";
        System.out.println("testRemoveProduct: PASSED");
    }

    public void testGetTotal() {
        setUp();
        cart.addProduct(testProduct, 2);
        assert cart.getTotal() == 20.0 : "Total should be 20.0";
        System.out.println("testGetTotal: PASSED");
    }

    public void testEmptyCart() {
        setUp();
        assert cart.isEmpty() : "New cart should be empty";
        assert cart.getItems().size() == 0 : "Cart should have 0 items";
        System.out.println("testEmptyCart: PASSED");
    }
}